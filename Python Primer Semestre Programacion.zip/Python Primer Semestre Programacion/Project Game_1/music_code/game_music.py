import pygame
import os

# Function to play all 5 songs
def play_musicmm():
    route_music = "Project Game_1/Music/main menu.mp3"

    if not os.path.exists(route_music):
        print(f"Error: song {route_music} not found.")
    else:
        pygame.mixer.music.load(route_music)
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.play(-1)
def play_music1():
    route_music = "Project Game_1/Music/music level1.mp3"
    
    if not os.path.exists(route_music):
        print(f"Error: song {route_music} not found.")
    else:
        pygame.mixer.music.load(route_music)
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.play(-1)
def play_music2():
    route_music = "Project Game_1/Music/music level2.mp3"

    if not os.path.exists(route_music):
        print(f"Error: song {route_music} not found.")
    else:
        pygame.mixer.music.load(route_music)
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.play(-1)
def play_music3():
    route_music = "Project Game_1/Music/music level3.mp3"

    if not os.path.exists(route_music):
        print(f"Error: song {route_music} not found.")
    else:
        pygame.mixer.music.load(route_music)
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.play(-1)
def play_music4():
    route_music = "Project Game_1/Music/music level4.mp3"

    if not os.path.exists(route_music):
        print(f"Error: song {route_music} not found.")
    else:
        pygame.mixer.music.load(route_music)
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.play(-1)


# enabling the file to be called
if __name__ == "__main__":
    """pygame.init()
    reproducir_musica1()

    
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Juego con Música")  # Aquí se corrige el error con las comillas

    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

    pygame.quit()  # Detener pygame cuando se cierre la ventana"""