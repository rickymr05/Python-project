import pygame
import os
import sys
from os import listdir
from os.path import isfile, join
from music_code.game_music import play_music1, play_music2, play_music3 , play_music4, play_musicmm

pygame.init()

# General Variables
WIDTH, HEIGHT = 1000, 500
pygame.display.set_caption("The Tower")
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
VEL = 5
WHITE = (250, 250, 250)
BLACK = (0, 0, 0)
COLOR = (255, 0, 0)
FPS = 60
PLAYER_VEL = 5 
window = pygame.display.set_mode((WIDTH, HEIGHT))
block_size = 40

# Background
BG = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'imagen.png')), (WIDTH, HEIGHT))

# Font
def get_font(size):
    return pygame.font.SysFont("algerian", size)

# Button Class
class Button:
    def __init__(self, text_input, x_pos, y_pos, width, height, base_color, hovering_color):
        self.rect = pygame.Rect(x_pos, y_pos, width, height)
        self.text_input = text_input
        self.base_color = base_color
        self.hovering_color = hovering_color
        self.text = get_font(30).render(self.text_input, True, WHITE)
        self.text_rect = self.text.get_rect(center=self.rect.center)

    def update(self, screen):
        color = self.hovering_color if self.rect.collidepoint(pygame.mouse.get_pos()) else self.base_color
        pygame.draw.rect(screen, color, self.rect)
        screen.blit(self.text, self.text_rect)

    def checkForInput(self, position):
        return self.rect.collidepoint(position)
    


# Lógica del juego principal
def play():
    def flip(sprites):
        return [pygame.transform.flip(sprite, True, False) for sprite in sprites]


    def load_sprite_sheets(dir1, dir2, width, height, direction=False):
        path = join("assets", dir1, dir2)
        images = [f for f in listdir(path) if isfile(join(path, f))]

        all_sprites = {}

        for image in images:
            sprite_sheet = pygame.image.load(join(path, image)).convert_alpha()

            sprites = []
            for i in range(sprite_sheet.get_width() // width):
                surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
                rect = pygame.Rect(i * width, 0, width, height)
                surface.blit(sprite_sheet, (0, 0), rect)
                sprites.append(pygame.transform.scale2x(surface))

            if direction:
                all_sprites[image.replace(".png", "") + "_right"] = sprites
                all_sprites[image.replace(".png", "") + "_left"] = flip(sprites)
            else:
                all_sprites[image.replace(".png", "")] = sprites

        return all_sprites

    def get_block(size):
        path = join("assets","Terrain", "Stone.png")
        image = pygame.image.load(path).convert_alpha()
        surface = pygame.Surface((size, size), pygame.SRCALPHA, 32)
        rect = pygame.Rect(0, 0, size, size)
        surface.blit(image, (0, 0), rect)
        return pygame.transform.scale2x(surface)


    class Player(pygame.sprite.Sprite):
        GRAVITY = 1
        SPRITES = load_sprite_sheets("MainCharacters", "Knight", 96, 60, True)
        ANIMATION_DELAY = 3

        def __init__(self, x, y, width, height):
            super(). __init__()
            self.rect = pygame.Rect(x, y, width, height)
            self.x_vel = 0
            self.y_vel = 0 
            self.mask = None
            self.direccion = "left"
            self.animation_count = 0
            self.fall_count = 0
            self.jump_count = 0
            self.sprite = self.SPRITES["idle_left"][0]
            self.update()

        def jump(self):
            if self.jump_count < 2:
                self.y_vel = -self.GRAVITY * 6
                self.animation_count = 0
                self.jump_count += 1 
                if self.jump_count == 1:
                    self.fall_count = 0
            

        def move(self, dx, dy):
            self.rect.x += dx
            self.rect.y += dy
        
        def move_left(self, vel):
            self.x_vel = -vel
            if self.x_vel < 0:
                if self.direccion != "left":
                    self.direccion  = "left"
                    self.animation_count = 0

        def move_right(self, vel):
            self.x_vel = vel
            if self.direccion != "right":
                self.direccion  = "right"
                self.animation_count = 0

        def loop(self, fps):
            self.y_vel += min(1, (self.fall_count / fps) * self.GRAVITY)
            self.move(self.x_vel, self.y_vel)

            self.fall_count += 1
            self.update_sprite()

        def landed (self):
            self.fall_count = 0
            self.y_vel = 0
            self.jump_count = 0
        
        def hit_head(self):
            self.count = 0
            self.y_vel *= -1

        def update_sprite(self):
            sprite_sheet= "idle"
            if self.y_vel  < 0:
                sprite_sheet = "jump"
            elif self.x_vel != 0:
                sprite_sheet = "run"
            
            
            sprite_sheet_name = sprite_sheet + "_" + self.direccion
            sprites = self.SPRITES[sprite_sheet_name]
            sprite_index = (self.animation_count // self.ANIMATION_DELAY) % len(sprites)
            self.sprite = sprites[sprite_index]
            self.animation_count += 1
            self.update() 
        
        def update(self):
            self.rect = self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))
            self.mask = pygame.mask.from_surface(self.sprite)

        def draw(self, win):
            win.blit(self.sprite, (self.rect.x, self.rect.y))

    class Object(pygame.sprite.Sprite):
        def __init__(self, x, y, width, height, name = None ):
            super().__init__()
            self.rect = pygame.Rect(x, y, width, height)
            self.image = pygame.Surface((width, height), pygame.SRCALPHA)
            self.width = width
            self.height = height
            self.name = name

        def draw(self, win):
            win.blit(self.image, (self.rect.x, self.rect.y))

    class Block(Object):
        def __init__(self, x, y, size):
            super().__init__(x, y, size, size)
            block = get_block(size)
            self.image.blit(block, (0, 0))
            self.mask = pygame.mask.from_surface(self.image)




    def get_background(name):
        image = pygame.image.load(join("assets","Background", name))
        _, _, width, height = image.get_rect()
        tiles = []

        for i in range(WIDTH // width + 1):
            for j in range(HEIGHT // height +1):
                pos = (i * width, j * height)
                tiles.append(pos)
        
        return tiles, image 


    def draw(window, background, bg_image, player, objects):
        for tile in background:
            window.blit(bg_image, tile)
        
        for obj in objects:
            obj.draw(window)
        
        player.draw(window)
        pygame.display.update()

    def handle_vertical_collision(player, objects, dy):
        collided_objects = []
        for obj in objects:
            if pygame.sprite.collide_mask(player, obj):
                if dy > 0:
                    player.rect.bottom = obj.rect.top
                    player.landed()
                elif dy < 0:
                    player.rect.top = obj.rect.bottom
                    player.hit_head()

            collided_objects.append(obj)
        
        return collided_objects

    def collide(player, objects, dx):
        player.move(dx, 0)
        player.update
        collided_object = None
        for obj in objects:
            if pygame.sprite.collide_mask(player, obj):
                collided_object = obj
                break
        
        player.move(-dx, 0)
        player.update()
        return collided_object

    def handle_move(player, objects):
        keys = pygame.key.get_pressed()
        

        player.x_vel = 0
        collide_left = collide(player, objects, -PLAYER_VEL * 3)
        collide_right = collide(player, objects, PLAYER_VEL * 3)

        if keys[pygame.K_LEFT] and not collide_left:
            if player.rect.left > - 75 :
                player.move_left(PLAYER_VEL) 
        if keys[pygame.K_RIGHT] and not collide_right and PLAYER_VEL < WIDTH:
            if player.rect.right < WIDTH + 75:
                player.move_right(PLAYER_VEL)

        handle_vertical_collision(player, objects, player.y_vel)
    
    def level_1():
        play_music1()
        objects = []
        for x in range(0, WIDTH, block_size):
            objects.append(Block(x, HEIGHT - block_size, block_size))
        floor_y = HEIGHT - 4 * block_size
        for x in range(0, WIDTH - block_size * 4, block_size):
            objects.append(Block(x, floor_y, block_size))
        floor2_y = HEIGHT - 7 * block_size
        for x in range(block_size * 5, WIDTH - block_size * 5, block_size):
            objects.append(Block(x, floor2_y, block_size))
        floor3_y = HEIGHT - 10 * block_size
        for x in range(WIDTH - block_size * 7, WIDTH - block_size * 2, block_size):
            objects.append(Block(x, floor3_y, block_size))
        goal_y = HEIGHT - 11 * block_size
        objects.append(Block(WIDTH - block_size, goal_y, block_size))
        player = Player(50, HEIGHT - 2 * block_size - 50, 50, 50)
        player.sprite = Player.SPRITES["idle_left"][0]

        return objects, player

    def level_2():
        play_music2()
        player = Player(50, HEIGHT - 2 * block_size - 50, 50, 50)
        player.sprite = Player.SPRITES["idle_left"][0]  
        objects = []
        for x in range(0, WIDTH, block_size):
            objects.append(Block(x, HEIGHT - block_size, block_size))
        floor_y = HEIGHT - 4 * block_size
        for x in range(0, WIDTH - block_size * 6, block_size * 2):
            objects.append(Block(x, floor_y, block_size))
        floor2_y = HEIGHT - 7 * block_size
        for x in range(block_size * 3, WIDTH - block_size * 8, block_size * 3):
            objects.append(Block(x, floor2_y, block_size))
        floor3_y = HEIGHT - 10 * block_size
        for x in range(block_size * 10, WIDTH - block_size * 3, block_size * 4):
            objects.append(Block(x, floor3_y, block_size))
        goal_y = HEIGHT - 11 * block_size
        objects.append(Block(WIDTH - block_size, goal_y, block_size))
        
        return objects, player

    def level_3():
        play_music3()
        objects = []
        for x in range(0, WIDTH, block_size):
            objects.append(Block(x, HEIGHT - block_size, block_size))
        floor_y = HEIGHT - 4 * block_size
        for x in range(0, WIDTH - block_size * 6, block_size * 4):
            objects.append(Block(x, floor_y, block_size))
        floor2_y = HEIGHT - 7 * block_size
        for x in range(block_size * 5, WIDTH - block_size * 6, block_size * 5):
            objects.append(Block(x, floor2_y, block_size))
        floor3_y = HEIGHT - 10 * block_size
        for x in range(block_size * 8, WIDTH - block_size * 3, block_size * 9):
            objects.append(Block(x, floor3_y, block_size))
        goal_y = HEIGHT - 11 * block_size
        objects.append(Block(WIDTH - block_size, goal_y, block_size))
        player = Player(50, HEIGHT - 2 * block_size - 50, 50, 50)
        player.sprite = Player.SPRITES["idle_left"][0]
        return objects, player

    def level_4():
        play_music4()
        objects = []
        for x in range(0, WIDTH, block_size):
            objects.append(Block(x, HEIGHT - block_size, block_size))
        floor_y = HEIGHT - 4 * block_size
        for x in range(0, WIDTH - block_size * 8, block_size * 3):
            objects.append(Block(x, floor_y, block_size))
        floor2_y = HEIGHT - 7 * block_size
        for x in range(block_size * 4, WIDTH - block_size * 7, block_size * 5):
            objects.append(Block(x, floor2_y, block_size))
        floor3_y = HEIGHT - 9 * block_size
        for x in range(block_size * 6, WIDTH - block_size * 3, block_size * 6):
            objects.append(Block(x, floor3_y, block_size))
        goal_y = HEIGHT - 11 * block_size
        objects.append(Block(WIDTH - block_size, goal_y, block_size))
        player = Player(50, HEIGHT - 2 * block_size - 50, 50, 50)
        player.sprite = Player.SPRITES["idle_left"][0]
        return objects, player
    
    

    def main(window):
        
        clock = pygame.time.Clock()
        background, bg_image = get_background("wallstone.png")
        levels = [level_1, level_2, level_3, level_4]
        current_level_index = 0
        
        
        
        objects, player = levels[current_level_index]() 

        run = True
        while run:
            clock.tick(FPS)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    break
            

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and player.jump_count < 2:
                        player.jump()

            player.loop(FPS)
            handle_move(player, objects)
            draw(window, background, bg_image, player, objects)

            for obj in objects:
                if isinstance(obj, Block) and player.rect.colliderect(obj.rect):
                    goal_y = HEIGHT - 11 * block_size  
                    if obj.rect.x == WIDTH - block_size and obj.rect.y == goal_y:
                        if current_level_index == len(levels) - 1: 
                            print("Game Over!")
                            run = False
                            break
                        else:
                            current_level_index += 1
                            player.x_vel = 0
                            player.y_vel = 0
                            player.jump_count = 0
                            objects, player = levels[current_level_index]()
                            player.sprite = Player.SPRITES["idle_left"][0]
                            break

                                            
        
        pygame.quit()
        quit()

    if __name__ == "__main__":
        main(window)

#main menu
def main_menu():
    play_musicmm()
    while True:
        
        SCREEN.blit(BG, (0, 0))
       

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(50).render("THE TOWER", True, "black")
        MENU_RECT = MENU_TEXT.get_rect(center=(WIDTH // 2, 100))

        PLAY_BUTTON = Button(text_input="PLAY", x_pos= WIDTH // 2 - 100, y_pos=250, width=200, height=60, 
                             base_color="green", hovering_color="darkgreen")
        QUIT_BUTTON = Button(text_input="QUIT", x_pos= WIDTH // 2 -100 , y_pos=350, width=200, height=60, 
                             base_color="red", hovering_color="darkred")

        SCREEN.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON, QUIT_BUTTON]:
            button.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()

main_menu()